../utils/pintos -v -k -T 10 --qemu  --filesys-size=2 -p build/tests/userprog/exec-arg -a exec-arg -p build/tests/userprog/child-args -a child-args -- -q  -f run exec-arg 
