../utils/pintos -v -k -T 10 --qemu  --filesys-size=2 -p build/tests/userprog/args-many -a args-many -- -q  -f run 'args-many a b c d e f g h i j k l m n o p q r s t u v' 
