../utils/pintos -v -k -T 10 --qemu  --filesys-size=2 -p build/tests/userprog/args-single -a args-single -- -q  -f run 'args-single onearg' 
