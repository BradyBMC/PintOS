../utils/pintos -v -k -T 10 --qemu  --filesys-size=2 -p build/tests/userprog/open-bad-ptr -a open-bad-ptr -- -q  -f run open-bad-ptr 
