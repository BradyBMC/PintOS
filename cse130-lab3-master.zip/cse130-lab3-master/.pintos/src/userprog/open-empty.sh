../utils/pintos -v -k -T 10 --qemu  --filesys-size=2 -p build/tests/userprog/open-empty -a open-empty -- -q  -f run open-empty 
