../utils/pintos -v -k -T 10 --qemu  --filesys-size=2 -p build/tests/userprog/create-long -a create-long -- -q  -f run create-long 
