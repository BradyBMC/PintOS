../utils/pintos -v -k -T 10 --qemu  --filesys-size=2 -p build/tests/userprog/write-bad-fd -a write-bad-fd -- -q  -f run write-bad-fd 
