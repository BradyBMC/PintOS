../utils/pintos -v -k -T 10 --qemu  --filesys-size=2 -p build/tests/userprog/wait-bad-pid d -a wait-bad-pid -- -q  -f run wait-bad-pid 
