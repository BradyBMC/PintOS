../utils/pintos -v -k -T 10 --qemu  --filesys-size=2 -p build/tests/userprog/write-normal -a write-normal -p ../tests/userprog/sample.txt -a sample.txt -- -q  -f run write-normal 
