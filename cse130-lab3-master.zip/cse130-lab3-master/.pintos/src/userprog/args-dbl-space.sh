../utils/pintos -v -k -T 10 --qemu  --filesys-size=2 -p build/tests/userprog/args-dbl-space -a args-dbl-space -- -q  -f run 'args-dbl-space two  spaces!' 
