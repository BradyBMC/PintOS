../utils/pintos -v -k -T 10 --qemu  --filesys-size=2 -p build/tests/userprog/write-stdin -a write-stdin -- -q  -f run write-stdin 
