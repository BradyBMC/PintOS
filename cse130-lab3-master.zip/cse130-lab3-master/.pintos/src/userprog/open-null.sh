../utils/pintos -v -k -T 10 --qemu  --filesys-size=2 -p build/tests/userprog/open-null -a open-null -- -q  -f run open-null 
