../utils/pintos -v -k -T 10 --qemu  --filesys-size=2 -p build/tests/userprog/exec-bad-ptr -a exec-bad-ptr -- -q  -f run exec-bad-ptr 
