../utils/pintos -v -k -T 10 --qemu  --filesys-size=2 -p build/tests/userprog/read-bad-fd -a read-bad-fd -- -q  -f run read-bad-fd 
