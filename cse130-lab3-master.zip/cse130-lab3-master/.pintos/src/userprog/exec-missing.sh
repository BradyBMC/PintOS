../utils/pintos -v -k -T 10 --qemu  --filesys-size=2 -p build/tests/userprog/exec-missing -a exec-missing -- -q  -f run exec-missing 
