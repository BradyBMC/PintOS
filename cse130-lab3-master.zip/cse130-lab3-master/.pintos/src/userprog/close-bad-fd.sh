../utils/pintos -v -k -T 10 --qemu  --filesys-size=2 -p build/tests/userprog/close-bad-fd -a close-bad-fd -- -q  -f run close-bad-fd 
