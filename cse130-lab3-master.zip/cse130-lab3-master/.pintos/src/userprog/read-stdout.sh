../utils/pintos -v -k -T 10 --qemu  --filesys-size=2 -p build/tests/userprog/read-stdout -a read-stdout -- -q  -f run read-stdout 
